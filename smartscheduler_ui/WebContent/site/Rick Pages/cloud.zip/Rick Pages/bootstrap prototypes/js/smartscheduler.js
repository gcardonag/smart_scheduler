var signIn = function(){
    alert("Test alert; please ignore");
}